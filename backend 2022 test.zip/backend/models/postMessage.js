import mongoose from "mongoose";

const postSchema = mongoose.Schema({
    dog_name: String,
    about: String,
    name: String,
    creator: String,
    breed: String,
    selectedFile: String,
    likes: {
        type: [String],
        default: []
    },
    createdAt: {
        type: Date,
        default: new Date()
    }
});

const PostMessage = mongoose.model('PostMessage', postSchema);

export default PostMessage;